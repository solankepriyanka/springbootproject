package com.bv.dao;

import com.bv.loginmodel.User;

public interface UserDao {
	
	public boolean validate(User u);
	

}


