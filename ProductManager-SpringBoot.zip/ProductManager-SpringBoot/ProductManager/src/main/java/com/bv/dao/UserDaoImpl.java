package com.bv.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.bv.connection.DBConnect;
import com.bv.loginmodel.User;

public class UserDaoImpl implements UserDao {
		
		@Override
		public boolean validate(User u) {
		
		
				boolean status = false;
				String sql = "select * from user "
						+ "where username = ? and password = ?";
				
				Connection con = DBConnect.getConnection();
				try {
					PreparedStatement pstmt = con.prepareStatement(sql);
					pstmt.setString(1, u.getUsername());
					pstmt.setString(2,u.getPassword());
					
				ResultSet rs = pstmt.executeQuery();
				
				if(rs.next())
				status = true;
			

				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				return status;
		}
}
